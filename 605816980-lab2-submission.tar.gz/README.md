# You Spin Me Round Robin

A implementation for round robin shceduling for a given workload and quantum length.

## Building

```shell
make
```

## Running

cmd for running TODO

```shell

./rr fileName quantumNum

ex: ./rr processes.txt 3

```


results 

expected output:

```shell

Average waiting time: 7.00
Average response time: 2.75

```


## Cleaning up

```shell
make clean
```
